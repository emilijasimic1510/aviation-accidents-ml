# 1. Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 2. Load the dataset
file_path = "aviation_accidents.csv"
df = pd.read_csv(file_path, quotechar='"', on_bad_lines='skip', encoding="utf-8")

# Keep only relevant columns
df = df[["Date", "Location", "Operator", "AC Type", "Aboard", "Fatalities", "Ground"]]

# Drop rows with missing values in any of these columns
df.dropna(inplace=True)

# Create target variable 'Fatal': 1 if fatalities > 0, else 0
df["Fatal"] = df["Fatalities"].apply(lambda x: 1 if x > 0 else 0)
print(df["Fatal"].value_counts())

# 3. Display basic data info
print("First 5 rows:")
print(df.head())

print("\nColumn info:")
print(df.info())

print("\nNumerical column stats:")
print(df.describe())

# 4. Check for missing values
print("\nMissing values by column:")
print(df.isnull().sum())

# 5. Visualize missing values (optional)
sns.heatmap(df.isnull(), cbar=False, cmap='viridis')
plt.title("Missing Values Heatmap")
plt.show()

print(df.columns)
print(df.columns.tolist())

# Keep only rows with at least 5 non-null values
df.dropna(thresh=5, inplace=True)

# Fill missing values

df["Aboard"] = df["Aboard"].fillna(df["Aboard"].mean())
df["Fatalities"] = df["Fatalities"].fillna(df["Fatalities"].mean())
df["Ground"] = df["Ground"].fillna(df["Ground"].mean())
df["AC Type"] = df["AC Type"].fillna(df["AC Type"].mode()[0])

# Recreate Fatal column

df["Fatal"] = df["Fatalities"].apply(lambda x: 1 if x > 0 else 0)

# Add synthetic non-fatal samples
dummy_data = pd.DataFrame({
    "Date": ["2000-01-01"] * 10,
    "Location": ["Testville"] * 10,
    "Operator": ["TestAir"] * 10,
    "AC Type": ["TestPlane"] * 10,
    "Aboard": [10] * 10,
    "Fatalities": [0] * 10,
    "Ground": [0] * 10
})
dummy_data["Fatal"] = dummy_data["Fatalities"].apply(lambda x: 1 if x > 0 else 0)
df = pd.concat([df, dummy_data], ignore_index=True)

print("\nTarget class distribution (Fatal):")
print(df["Fatal"].value_counts())

# Encode categorical variables
from sklearn.preprocessing import LabelEncoder

label_cols = ["Operator", "Location", "AC Type"]
le = LabelEncoder()

for col in label_cols:
    df[col] = le.fit_transform(df[col].astype(str))

print("\nEncoded sample values:")
print(df[label_cols].head())

# Normalize numerical features
from sklearn.preprocessing import MinMaxScaler

scaler = MinMaxScaler()
df[["Aboard", "Fatalities", "Ground"]] = scaler.fit_transform(df[["Aboard", "Fatalities", "Ground"]])

# Extract year from Date
df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
df["Year"] = df["Date"].dt.year
df.fillna(0, inplace=True)
print("\nAny NaN values left?", df.isnull().sum().sum())

# Prepare data for modeling
X = df.drop(columns=["Fatal", "Date"])
y = df["Fatal"]

from sklearn.model_selection import train_test_split

print(df[["Date", "Year"]].head(10))
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print("Preprocessing complete!")
print(df.head())

# Train and evaluate models
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# Random Forest
rf_model = RandomForestClassifier(random_state=42)
rf_model.fit(X_train, y_train)
rf_preds = rf_model.predict(X_test)

print("\nRandom Forest Evaluation:")
print(confusion_matrix(y_test, rf_preds))
print(classification_report(y_test, rf_preds))
print(f"Accuracy: {accuracy_score(y_test, rf_preds) * 100:.2f}%")

# Logistic Regression
log_model = LogisticRegression(max_iter=1000)
log_model.fit(X_train, y_train)
log_preds = log_model.predict(X_test)

print("\nLogistic Regression Evaluation:")
print(confusion_matrix(y_test, log_preds))
print(classification_report(y_test, log_preds))
print(f"Accuracy: {accuracy_score(y_test, log_preds) * 100:.2f}%")

# Model comparison plot
models = ['Random Forest', 'Logistic Regression']
accuracies = [
    accuracy_score(y_test, rf_preds),
    accuracy_score(y_test, log_preds)
]

plt.bar(models, accuracies)
plt.ylabel('Accuracy')
plt.title('Model Performance Comparison')
plt.ylim(0, 1)
plt.show()

# Feature importance
importances = rf_model.feature_importances_
feature_names = X.columns
print(f"Train acc RF: {rf_model.score(X_train, y_train):.2f}")
print(f"Test acc RF: {accuracy_score(y_test, rf_preds):.2f}")

plt.figure(figsize=(10, 5))
sns.barplot(x=importances, y=feature_names)
plt.title("Feature Importance (Random Forest)")
plt.show()

# Confusion matrix visualization
cm = confusion_matrix(y_test, rf_preds)
sns.heatmap(cm, annot=True, fmt='d', cmap='Purples')
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix - Random Forest")
plt.show()

print("Train set evaluation (Random Forest):")
train_preds = rf_model.predict(X_train)
print(classification_report(y_train, train_preds))

# Visualizations

# Fatal vs. non-fatal accidents
plt.figure(figsize=(6, 4))
sns.countplot(data=df, x="Fatal")
plt.title("Distribution of Fatal vs. Non-Fatal Accidents")
plt.xticks([0, 1], ['Non-Fatal', 'Fatal'])
plt.xlabel("Accident Type")
plt.ylabel("Number of Accidents")
plt.tight_layout()
plt.show()

# Accidents by year
plt.figure(figsize=(12, 5))
sns.histplot(data=df, x="Year", bins=30, kde=False)
plt.title("Number of Accidents per Year")
plt.xlabel("Year")
plt.ylabel("Number of Accidents")
plt.tight_layout()
plt.show()

# Top 10 aircraft types

top_ac_types = df["AC Type"].value_counts().nlargest(10)
plt.figure(figsize=(10, 5))
sns.barplot(x=top_ac_types.values, y=top_ac_types.index)
plt.title("Top 10 Aircraft Types Involved in Accidents")
plt.xlabel("Number of Accidents")
plt.ylabel("Aircraft Type")
plt.tight_layout()
plt.show()

# Top 10 locations

top_locations = df["Location"].value_counts().nlargest(10)
plt.figure(figsize=(10, 5))
sns.barplot(x=top_locations.values, y=top_locations.index)
plt.title("Top 10 Locations with Most Accidents")
plt.xlabel("Number of Accidents")
plt.ylabel("Location")
plt.tight_layout()
plt.show()

# Scatter: Passengers vs. Fatalities
plt.figure(figsize=(8, 6))
sns.scatterplot(data=df, x="Aboard", y="Fatalities", hue="Fatal", palette="coolwarm")
plt.title("Passengers vs. Fatalities")
plt.xlabel("Total Aboard")
plt.ylabel("Fatalities")
plt.tight_layout()
plt.show()

# Correlation heatmap
plt.figure(figsize=(8, 6))
sns.heatmap(df[["Aboard", "Fatalities", "Ground", "Year"]].corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Between Numerical Features")
plt.tight_layout()
plt.show()

# Fatal accidents over time
fatal_per_year = df.groupby("Year")["Fatal"].sum()
plt.figure(figsize=(12, 5))
fatal_per_year.plot()
plt.title("Trend of Fatal Accidents Over the Years")
plt.xlabel("Year")
plt.ylabel("Number of Fatal Accidents")
plt.tight_layout()
plt.show()

# Top 10 operators

top_operators = df["Operator"].value_counts().nlargest(10)
plt.figure(figsize=(10, 5))
sns.barplot(x=top_operators.values, y=top_operators.index)
plt.title("Top 10 Operators by Number of Accidents")
plt.xlabel("Number of Accidents")
plt.ylabel("Operator")
plt.tight_layout()
plt.show()
