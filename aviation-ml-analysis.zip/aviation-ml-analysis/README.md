✈️ Aviation Accidents ML Classifier

This project uses aviation accident data to predict whether an accident was fatal or not, using machine learning models such as Random Forest and Logistic Regression.


📁 Project Structure

aviation-ml/
│
├── aviation_accidents.csv   # Dataset
├── main.py                  # Main Python file with the full pipeline
├── README.md                # Project documentation


⚙️ Technologies Used

    Python 3.x

    Pandas

    NumPy

    scikit-learn

    Matplotlib

    Seaborn

📊 Project Workflow

    Data loading

    Data cleaning and preprocessing (handling missing values)

    Categorical data encoding

    Feature scaling / normalization

    Train/test split

    Model training:

        Random Forest

        Logistic Regression

    Model evaluation:

        Confusion Matrix

        Classification Report

        Accuracy Score

    Visualization:

        Missing values heatmap

        Model accuracy comparison

        Feature importance

✅ Results

    Both models achieved 100% accuracy on this dataset, which may suggest overfitting due to the small number of examples.

    Random Forest was used to determine feature importance.

📈 Visualizations

The project includes various visualizations such as:

    Missing value heatmap

    Model performance comparison

    Feature importance bar plot

    Distribution of fatal vs. non-fatal crashes

    Most common aircraft types and locations

    Passenger count vs. fatalities scatter plot

    Yearly trends of accidents and fatal crashes

🗂️ Dataset Overview

The dataset includes information about:

    Accident date and location

    Aircraft type

    Number of people aboard, fatalities, and people injured on the ground

    Whether the accident was fatal or not

🧠 Notes

    The project includes additional "dummy" records with no fatalities to help balance the target class Fatal = 0.

    In the future, it would be beneficial to process the Summary column using NLP techniques for further analysis.


👩‍💻 Author

Djordje Ristic
Year: 2025